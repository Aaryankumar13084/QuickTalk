const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 800;
canvas.height = 600;

let player = { x: 375, y: 500, width: 50, height: 50, speed: 8 };
let obstacles = [];
let gameOver = false;
let score = 0;

// Listen for arrow key presses
document.addEventListener('keydown', movePlayer);

function movePlayer(event) {
  if (event.key === 'ArrowLeft' && player.x > 0) {
    player.x -= player.speed;
  }
  if (event.key === 'ArrowRight' && player.x + player.width < canvas.width) {
    player.x += player.speed;
  }
}

// Create falling obstacles
function createObstacle() {
  const x = Math.random() * (canvas.width - 50);
  obstacles.push({ x, y: 0, width: 50, height: 50, speed: 3 + Math.random() * 3 });
}

// Update obstacle positions and check for collisions
function updateGame() {
  obstacles.forEach((obstacle, index) => {
    obstacle.y += obstacle.speed;

    // Check for collision with the player
    if (
      obstacle.x < player.x + player.width &&
      obstacle.x + obstacle.width > player.x &&
      obstacle.y < player.y + player.height &&
      obstacle.y + obstacle.height > player.y
    ) {
      gameOver = true;
    }

    // Remove obstacles that fall off screen
    if (obstacle.y > canvas.height) {
      obstacles.splice(index, 1);
      score++;
    }
  });
}

// Draw the player, obstacles, and score
function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw player
  ctx.fillStyle = 'lightblue';
  ctx.fillRect(player.x, player.y, player.width, player.height);

  // Draw obstacles
  ctx.fillStyle = 'red';
  obstacles.forEach((obstacle) => {
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
  });

  // Draw score
  ctx.fillStyle = 'white';
  ctx.font = '20px Arial';
  ctx.fillText(`Score: ${score}`, 10, 30);

  // Game Over message
  if (gameOver) {
    ctx.fillStyle = 'white';
    ctx.font = '40px Arial';
    ctx.fillText('Game Over!', canvas.width / 2 - 100, canvas.height / 2);
    cancelAnimationFrame(animationId);
  }
}

// Game loop
let animationId;
function gameLoop() {
  updateGame();
  drawGame();

  if (!gameOver) {
    animationId = requestAnimationFrame(gameLoop);
  }
}

// Start the game
setInterval(createObstacle, 1000);
gameLoop(); 